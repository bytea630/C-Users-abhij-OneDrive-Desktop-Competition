@echo off
title KrishiKart - Agricultural Equipment Store
echo =================================================================
echo  Starting KrishiKart (Agricultural Equipment & Farming Tools)
echo =================================================================

REM Check if Python is available in PATH
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [INFO] Running with system Python...
    python app.py
    goto end
)

REM Check uv Python location
if exist "%APPDATA%\uv\python\cpython-3.12-windows-x86_64-none\python.exe" (
    echo [INFO] Running with Python 3.12...
    "%APPDATA%\uv\python\cpython-3.12-windows-x86_64-none\python.exe" app.py
    goto end
)

REM Fallback: Open index.html directly in default browser
echo [INFO] Opening KrishiKart directly in your browser...
start index.html

:end
pause
