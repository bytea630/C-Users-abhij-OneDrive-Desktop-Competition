#!/usr/bin/env python3
"""
KrishiKart - All-in-One Python Backend & SQLite Store
Runs automatically without any external packages or npm.
"""

import http.server
import json
import os
import sqlite3
import sys
import threading
import urllib.parse
import webbrowser
from http import HTTPStatus

PORT = 8000
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "krishikart.db")


# ------------------------------------------------------------------------------
# Database Setup (All-in-One SQLite)
# ------------------------------------------------------------------------------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        category_name TEXT NOT NULL,
        brand TEXT NOT NULL,
        price INTEGER NOT NULL,
        original_price INTEGER NOT NULL,
        discount_percent INTEGER NOT NULL,
        rating REAL NOT NULL,
        review_count INTEGER NOT NULL,
        stock INTEGER NOT NULL,
        image_url TEXT NOT NULL,
        badge TEXT,
        subsidy_info TEXT,
        is_assured INTEGER DEFAULT 1,
        description TEXT NOT NULL,
        specs_json TEXT NOT NULL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT NOT NULL,
        customer_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        pincode TEXT NOT NULL,
        total_amount INTEGER NOT NULL,
        payment_method TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    cursor.execute("SELECT COUNT(*) FROM products")
    if cursor.fetchone()[0] == 0:
        items = [
            (1, "Shaktiman 7HP Heavy Duty Power Weeder & Rotary Tiller (Petrol)", "tractors-tillers", "Tractors & Tillers", "Shaktiman Agro", 38500, 49000, 21, 4.6, 1420, 18, "static/images/tiller.svg", "TOP SELLER", "Eligible for 30% State Subsidy under SMAM Scheme", 1, "Powerful 7HP 212cc 4-stroke petrol cultivator with 32 curved rotary blades.", '{"Engine":"212cc 4-Stroke OHV","Working Width":"3.5 Feet","Blades":"32 Curved","Fuel Tank":"3.6L","Warranty":"2 Years"}'),
            (2, "Kirloskar 5 HP Single Phase Borewell Submersible Water Pump Set", "water-pumps", "Pumps & Irrigation", "Kirloskar", 18450, 24999, 26, 4.7, 2840, 24, "static/images/pump.svg", "BEST DEAL", "10% Instant Discount with Kisan Credit Card", 1, "100mm water-filled submersible pump set with 100% pure copper winding.", '{"Power":"5.0 HP (3.7 kW)","Discharge":"350-1200 LPM","Head Range":"15-55m","Outlet":"2.5 Inches","Warranty":"18 Months"}'),
            (3, "Neptune 16L Dual Function 2-in-1 Battery & Manual Knapsack Sprayer", "sprayers", "Sprayers & Pest", "Neptune", 2499, 3999, 37, 4.4, 4120, 65, "static/images/sprayer.svg", "FARMERS CHOICE", "Free Express Delivery | 4 Brass Nozzles Included", 1, "16-liter heavy grade tank with 12V 8Ah sealed rechargeable battery and backup pump.", '{"Tank":"16 Litres","Battery":"12V 8Ah","Working Time":"5-6 Hours","Pressure":"0.15-0.45 MPa","Warranty":"1 Year"}'),
            (4, "KisanKraft 35cc 4-Stroke Heavy Duty Brush Cutter & Harvester", "harvesting", "Harvesting & Cutters", "KisanKraft", 13900, 19500, 28, 4.5, 890, 15, "static/images/brushcutter.svg", "HOT DEAL", "Free Paddy Harvester Collector Attachment Included", 1, "Multi-purpose 4-stroke engine brush cutter for wheat, paddy, grass and brush clearing.", '{"Engine":"35.8cc 4-Stroke OHV","Power":"1.5 HP @ 7000 RPM","Blades":"80T Carbide + 3T Blade","Warranty":"1 Year"}'),
            (5, "Falcon Heavy Drop-Forged Steel Agricultural Spade (Phawra / Kodali)", "hand-tools", "Hand Tools", "Falcon", 749, 1199, 37, 4.8, 3210, 80, "static/images/spade.svg", "TOP RATED", "Free delivery on agricultural hand tools", 1, "Indestructible drop-forged high-carbon EN-9 steel spade with seasoned 48-inch handle.", '{"Steel":"Drop-Forged EN-9 High Carbon","Blade":"9.5 x 8.5 Inches","Handle":"48-Inch Ash Wood","Weight":"2.25 kg"}'),
            (6, "Jain Drip Irrigation 1 Acre Complete Micro-Irrigation Kit", "water-pumps", "Pumps & Irrigation", "Jain Irrigation", 14200, 19800, 28, 4.6, 1150, 12, "static/images/drip.svg", "AGRI CERTIFIED", "Save up to 60% Irrigation Water & Boost Yield", 1, "Complete 1-acre drip kit including 1000m inline lateral pipe and disc screen filter.", '{"Lateral":"16mm UV Class 2 (1000m)","Dripper Spacing":"40 cm (2.4 LPH)","Filter":"2-Inch Disc Filter","Coverage":"1 Acre"}'),
            (7, "Vardhman 3HP Chaff Cutter Machine with Heavy Flywheel & Reversible Gear", "farm-tech", "Dairy & Machinery", "Vardhman", 26500, 34000, 22, 4.7, 730, 10, "static/images/chaffcutter.svg", "DAIRY SPECIAL", "Approved for Dairy Development Subsidies", 1, "Commercial 3HP motor chaff cutter for cows and buffaloes. High capacity cutting 800-1000 kg/hr.", '{"Motor":"3.0 HP 100% Copper","Blades":"3 Tempered High-Carbon","Capacity":"800-1000 kg Fodder/Hr","Warranty":"2 Years"}'),
            (8, "Tata Agrico Stainless Steel Serrated Harvesting Sickles (Pack of 2)", "hand-tools", "Hand Tools", "Tata Agrico", 429, 650, 34, 4.7, 5670, 150, "static/images/sickle.svg", "BESTSELLER", "Genuine Tata Agrico laser-marked authentic product", 1, "High-manganese alloy steel sickles with micro-serrated sharp teeth.", '{"Pack":"2 Sickles (Daranti)","Steel":"Tata High-Manganese Alloy","Edge":"Micro-Serrated Teeth","Weight":"275g each"}'),
            (9, "Balwaan HTP 3-Piston Triplex Power Sprayer Pump Set (50 Bar)", "sprayers", "Sprayers & Pest", "Balwaan Krishi", 8999, 12999, 30, 4.6, 1380, 20, "static/images/htpsprayer.svg", "ORCHARD SPECIAL", "Includes 50m Heavy Hose Pipe + 90cm Turbo Brass Spray Gun", 1, "High pressure triplex pump with ceramic coated pistons for orchard spraying up to 40 feet.", '{"Pressure":"40-50 Bar","Discharge":"18-22 LPM","Hose":"50m 5-Ply Braided","Gun":"90cm Turbo Brass Gun"}'),
            (10, "AgroStar 9-Tyne Spring Loaded Heavy Duty Tractor Cultivator", "tractors-tillers", "Tractors & Tillers", "AgroStar", 29800, 38000, 21, 4.5, 560, 8, "static/images/cultivator.svg", "TRACTOR MOUNT", "Eligible for Central Farm Mechanization Subsidies", 1, "Tractor mounted 9-tyne cultivator with dual compression springs per tyne.", '{"Tractor":"35-55 HP","Working Width":"7.0 Feet","Tynes":"9 Forged Steel (28mm)","Weight":"245 kg"}'),
            (11, "GrainPro Digital 14-Crop Moisture Meter with Backlit LCD Screen", "farm-tech", "Dairy & Machinery", "GrainPro", 3850, 5500, 30, 4.4, 920, 35, "static/images/moisturemeter.svg", "SMART AGRI", "Accurate Mandi & Storage Testing in 3 Seconds", 1, "High precision twin probe grain moisture tester for 14 major crops.", '{"Moisture Range":"5% to 40%","Accuracy":"± 0.5%","Crops":"14 Major Crops","Probe":"30cm Dual Stainless"}'),
            (12, "Sharpex 10-Inch Telescopic Extendable Hedge & Tree Pruning Shear", "hand-tools", "Hand Tools", "Sharpex", 1299, 1999, 35, 4.5, 1840, 45, "static/images/shears.svg", "TOP VALUE", "Japanese SK-5 Steel Blade with Teflon Coating", 1, "Telescopic handles extend from 25 to 33 inches to easily prune high branches in orchards.", '{"Blade":"10-Inch SK-5 Carbon Steel","Handles":"Telescopic 25\" to 33\"","Weight":"1.18 kg"}')
        ]
        cursor.executemany("""
        INSERT INTO products (
            id, name, category, category_name, brand, price, original_price,
            discount_percent, rating, review_count, stock, image_url, badge,
            subsidy_info, is_assured, description, specs_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, items)

    conn.commit()
    conn.close()


# ------------------------------------------------------------------------------
# HTTP Request Handler (All-in-One Server)
# ------------------------------------------------------------------------------
class KrishiHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # Homepage
        if path == "/" or path == "/index.html":
            self.send_file(os.path.join(BASE_DIR, "index.html"), "text/html; charset=utf-8")
            return

        # Serve static assets
        if path == "/style.css":
            self.send_file(os.path.join(BASE_DIR, "style.css"), "text/css")
            return
        if path == "/script.js":
            self.send_file(os.path.join(BASE_DIR, "script.js"), "application/javascript")
            return

        # API: Products List
        if path == "/api/products":
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM products ORDER BY id ASC").fetchall()
            products = [dict(r) for r in rows]
            conn.close()
            self.send_json(products)
            return

        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length > 0 else b"{}"

        try:
            data = json.loads(body.decode("utf-8")) if body else {}
        except Exception:
            data = {}

        # API: Order placement
        if path == "/api/order":
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO orders (order_number, customer_name, phone, address, pincode, total_amount, payment_method)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                data.get("order_number", "KK-100001"),
                data.get("customer_name", "Farmer"),
                data.get("phone", ""),
                data.get("address", ""),
                data.get("pincode", ""),
                data.get("total_amount", 0),
                data.get("payment_method", "Cash on Delivery")
            ))
            conn.commit()
            conn.close()
            self.send_json({"status": "success", "message": "Order saved"})
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Not found")

    def send_json(self, data):
        content = json.dumps(data).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def send_file(self, filepath, mime):
        if not os.path.exists(filepath):
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        with open(filepath, "rb") as f:
            data = f.read()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main():
    if sys.platform == "win32":
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass

    init_db()
    url = f"http://127.0.0.1:{PORT}"
    print("=" * 60)
    print("KrishiKart Agricultural Store Server")
    print(f">> Running on: {url}")
    print(">> Opening browser automatically...")
    print("=" * 60)

    threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    httpd = http.server.ThreadingHTTPServer(("", PORT), KrishiHandler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping KrishiKart server.")
        httpd.server_close()


if __name__ == "__main__":
    main()
