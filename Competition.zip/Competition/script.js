/**
 * KrishiKart - Single Lightweight JavaScript File
 * Complete Flipkart-style client logic (Search, Filters, Cart, Details, Checkout)
 */

// Embedded Agricultural Equipment Dataset (Works with SQLite API & offline)
const DEFAULT_PRODUCTS = [
  {
    id: 1,
    name: "Shaktiman 7HP Heavy Duty Power Weeder & Rotary Tiller (Petrol)",
    category: "tractors-tillers",
    category_name: "Tractors & Tillers",
    brand: "Shaktiman Agro",
    price: 38500,
    original_price: 49000,
    discount_percent: 21,
    rating: 4.6,
    review_count: 1420,
    stock: 18,
    image_url: "static/images/tiller.svg",
    badge: "TOP SELLER",
    subsidy_info: "Eligible for 30% State Subsidy under SMAM Scheme",
    is_assured: 1,
    description: "Powerful 7HP 212cc 4-stroke petrol cultivator with 32 curved rotary blades. Perfect for sugarcane, cotton, and vegetables.",
    specs: { "Engine": "212cc 4-Stroke OHV", "Working Width": "3.5 Feet", "Blades": "32 Curved Blades", "Fuel Tank": "3.6L", "Warranty": "2 Years" }
  },
  {
    id: 2,
    name: "Kirloskar 5 HP Single Phase Borewell Submersible Water Pump Set",
    category: "water-pumps",
    category_name: "Pumps & Irrigation",
    brand: "Kirloskar",
    price: 18450,
    original_price: 24999,
    discount_percent: 26,
    rating: 4.7,
    review_count: 2840,
    stock: 24,
    image_url: "static/images/pump.svg",
    badge: "BEST DEAL",
    subsidy_info: "10% Instant Discount with Kisan Credit Card (KCC)",
    is_assured: 1,
    description: "100mm water-filled submersible pump set with 100% pure copper winding. Designed for high discharge and rural voltage ranges.",
    specs: { "Power": "5.0 HP (3.7 kW)", "Discharge": "350-1200 LPM", "Head Range": "15-55m", "Outlet": "2.5 Inches", "Warranty": "18 Months" }
  },
  {
    id: 3,
    name: "Neptune 16L Dual Function 2-in-1 Battery & Manual Knapsack Sprayer",
    category: "sprayers",
    category_name: "Sprayers & Pest",
    brand: "Neptune",
    price: 2499,
    original_price: 3999,
    discount_percent: 37,
    rating: 4.4,
    review_count: 4120,
    stock: 65,
    image_url: "static/images/sprayer.svg",
    badge: "FARMERS CHOICE",
    subsidy_info: "Free Express Delivery | 4 Brass Nozzles Included",
    is_assured: 1,
    description: "16-liter heavy grade tank with 12V 8Ah sealed rechargeable battery and manual backup pump lever. Sprays up to 25 tanks per charge.",
    specs: { "Tank": "16 Litres Virgin Plastic", "Battery": "12V 8Ah Rechargeable", "Working Time": "5-6 Hours", "Pressure": "0.15-0.45 MPa", "Warranty": "1 Year" }
  },
  {
    id: 4,
    name: "KisanKraft 35cc 4-Stroke Heavy Duty Brush Cutter & Harvester",
    category: "harvesting",
    category_name: "Harvesting & Cutters",
    brand: "KisanKraft",
    price: 13900,
    original_price: 19500,
    discount_percent: 28,
    rating: 4.5,
    review_count: 890,
    stock: 15,
    image_url: "static/images/brushcutter.svg",
    badge: "HOT DEAL",
    subsidy_info: "Free Paddy Harvester Collector Attachment (Worth ₹1,800)",
    is_assured: 1,
    description: "Multi-purpose 4-stroke engine brush cutter for wheat, paddy, grass and brush clearing. Low vibration, no 2T oil mixing needed.",
    specs: { "Engine": "35.8cc 4-Stroke OHV", "Power": "1.5 HP @ 7000 RPM", "Blades": "80T Carbide + 3T Blade + Harvester", "Fuel Tank": "0.65L", "Warranty": "1 Year" }
  },
  {
    id: 5,
    name: "Falcon Heavy Drop-Forged Steel Agricultural Spade (Phawra / Kodali)",
    category: "hand-tools",
    category_name: "Hand Tools",
    brand: "Falcon",
    price: 749,
    original_price: 1199,
    discount_percent: 37,
    rating: 4.8,
    review_count: 3210,
    stock: 80,
    image_url: "static/images/spade.svg",
    badge: "TOP RATED",
    subsidy_info: "Free delivery on agricultural hand tools",
    is_assured: 1,
    description: "Indestructible drop-forged high-carbon EN-9 steel spade with seasoned 48-inch ash hardwood handle for digging and trenching.",
    specs: { "Steel": "Drop-Forged EN-9 High Carbon", "Blade": "9.5 x 8.5 Inches", "Handle": "48-Inch Seasoned Ash Wood", "Weight": "2.25 kg" }
  },
  {
    id: 6,
    name: "Jain Drip Irrigation 1 Acre Complete Micro-Irrigation Kit",
    category: "water-pumps",
    category_name: "Pumps & Irrigation",
    brand: "Jain Irrigation",
    price: 14200,
    original_price: 19800,
    discount_percent: 28,
    rating: 4.6,
    review_count: 1150,
    stock: 12,
    image_url: "static/images/drip.svg",
    badge: "AGRI CERTIFIED",
    subsidy_info: "Save up to 60% Irrigation Water & Boost Yield",
    is_assured: 1,
    description: "Complete 1-acre drip kit including 1000m inline lateral pipe, disc screen filter, and venturi fertilizer injector for fruits and vegetables.",
    specs: { "Lateral": "16mm UV Class 2 (1000m)", "Dripper Spacing": "40 cm (2.4 LPH)", "Filter": "2-Inch Disc Filter", "Coverage": "1 Acre (4000 sq.m)" }
  },
  {
    id: 7,
    name: "Vardhman 3HP Chaff Cutter Machine with Heavy Flywheel & Reversible Gear",
    category: "farm-tech",
    category_name: "Dairy & Machinery",
    brand: "Vardhman",
    price: 26500,
    original_price: 34000,
    discount_percent: 22,
    rating: 4.7,
    review_count: 730,
    stock: 10,
    image_url: "static/images/chaffcutter.svg",
    badge: "DAIRY SPECIAL",
    subsidy_info: "Approved for Dairy Development Subsidies",
    is_assured: 1,
    description: "Commercial 3HP motor chaff cutter for cows and buffaloes. High capacity cutting of 800-1000 kg/hr with safety reverse gearbox.",
    specs: { "Motor": "3.0 HP 100% Copper (230V)", "Blades": "3 Tempered High-Carbon", "Capacity": "800-1000 kg Fodder/Hr", "Warranty": "2 Years" }
  },
  {
    id: 8,
    name: "Tata Agrico Stainless Steel Serrated Harvesting Sickles (Pack of 2)",
    category: "hand-tools",
    category_name: "Hand Tools",
    brand: "Tata Agrico",
    price: 429,
    original_price: 650,
    discount_percent: 34,
    rating: 4.7,
    review_count: 5670,
    stock: 150,
    image_url: "static/images/sickle.svg",
    badge: "BESTSELLER",
    subsidy_info: "Genuine Tata Agrico laser-marked authentic product",
    is_assured: 1,
    description: "High-manganese alloy steel sickles with micro-serrated sharp teeth for effortless paddy, wheat, and grass harvesting.",
    specs: { "Pack": "2 Sickles (Daranti)", "Steel": "Tata High-Manganese Alloy", "Edge": "Micro-Serrated Teeth", "Weight": "275g each" }
  },
  {
    id: 9,
    name: "Balwaan HTP 3-Piston Triplex Power Sprayer Pump Set (50 Bar)",
    category: "sprayers",
    category_name: "Sprayers & Pest",
    brand: "Balwaan Krishi",
    price: 8999,
    original_price: 12999,
    discount_percent: 30,
    rating: 4.6,
    review_count: 1380,
    stock: 20,
    image_url: "static/images/htpsprayer.svg",
    badge: "ORCHARD SPECIAL",
    subsidy_info: "Includes 50m Heavy Hose Pipe + 90cm Turbo Brass Spray Gun",
    is_assured: 1,
    description: "High pressure triplex pump with ceramic coated pistons for orchard spraying up to 40 feet vertical reach.",
    specs: { "Pressure": "40-50 Bar (580-725 PSI)", "Discharge": "18-22 LPM", "Hose": "50m 5-Ply Braided", "Gun": "90cm Turbo Brass Gun" }
  },
  {
    id: 10,
    name: "AgroStar 9-Tyne Spring Loaded Heavy Duty Tractor Cultivator",
    category: "tractors-tillers",
    category_name: "Tractors & Tillers",
    brand: "AgroStar",
    price: 29800,
    original_price: 38000,
    discount_percent: 21,
    rating: 4.5,
    review_count: 560,
    stock: 8,
    image_url: "static/images/cultivator.svg",
    badge: "TRACTOR MOUNT",
    subsidy_info: "Eligible for Central Farm Mechanization Subsidies",
    is_assured: 1,
    description: "Tractor mounted 9-tyne cultivator with dual compression springs per tyne. Uproots deep weeds and breaks hard soil pans without breaking.",
    specs: { "Tractor": "35-55 HP (Cat-II Linkage)", "Working Width": "7.0 Feet", "Tynes": "9 Forged Steel (28mm)", "Weight": "245 kg" }
  },
  {
    id: 11,
    name: "GrainPro Digital 14-Crop Moisture Meter with Backlit LCD Screen",
    category: "farm-tech",
    category_name: "Dairy & Machinery",
    brand: "GrainPro",
    price: 3850,
    original_price: 5500,
    discount_percent: 30,
    rating: 4.4,
    review_count: 920,
    stock: 35,
    image_url: "static/images/moisturemeter.svg",
    badge: "SMART AGRI",
    subsidy_info: "Accurate Mandi & Storage Testing in 3 Seconds",
    is_assured: 1,
    description: "High precision twin probe grain moisture tester for Wheat, Paddy, Rice, Maize, Soybean, Mustard, and Pulses to avoid mandi deductions.",
    specs: { "Moisture Range": "5% to 40%", "Accuracy": "± 0.5%", "Crops": "14 Major Crops", "Probe": "30cm Dual Stainless Steel" }
  },
  {
    id: 12,
    name: "Sharpex 10-Inch Telescopic Extendable Hedge & Tree Pruning Shear",
    category: "hand-tools",
    category_name: "Hand Tools",
    brand: "Sharpex",
    price: 1299,
    original_price: 1999,
    discount_percent: 35,
    rating: 4.5,
    review_count: 1840,
    stock: 45,
    image_url: "static/images/shears.svg",
    badge: "TOP VALUE",
    subsidy_info: "Japanese SK-5 Steel Blade with Teflon Rust-Proof Coating",
    is_assured: 1,
    description: "Telescopic handles extend from 25 to 33 inches to easily prune high branches in mango, citrus, and pomegranate orchards.",
    specs: { "Blade": "10-Inch SK-5 Carbon Steel", "Handles": "Telescopic 25\" to 33\"", "Weight": "1.18 kg" }
  }
];

// App State
let products = [...DEFAULT_PRODUCTS];
let filtered = [...DEFAULT_PRODUCTS];
let selectedCategory = "all";
let selectedSort = "popularity";
let cart = JSON.parse(localStorage.getItem("krishi_cart") || "[]");

// Format Indian Rupee currency
const fmtINR = (val) => "₹" + Number(val).toLocaleString("en-IN");

// Toast
function showToast(msg) {
  let t = document.getElementById("toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "toast";
    t.className = "toast";
    document.body.appendChild(t);
  }
  t.textContent = "✓ " + msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2500);
}

// Init
document.addEventListener("DOMContentLoaded", () => {
  loadProductsFromBackend();
  renderProducts();
  updateCartBadge();

  // Search input
  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("input", applyFilters);
  }
});

// Load from SQLite API if available
async function loadProductsFromBackend() {
  try {
    const res = await fetch("/api/products");
    if (res.ok) {
      const data = await res.json();
      if (data && data.length > 0) {
        products = data.map(p => ({
          ...p,
          specs: typeof p.specs_json === "string" ? JSON.parse(p.specs_json) : (p.specs || {})
        }));
        applyFilters();
      }
    }
  } catch (e) {
    // Falls back seamlessly to DEFAULT_PRODUCTS
  }
}

// Category filter
function setCategory(cat, el) {
  selectedCategory = cat;
  document.querySelectorAll(".cat-item").forEach(item => item.classList.remove("active"));
  if (el) el.classList.add("active");
  
  const radio = document.querySelector(`input[name="sideCat"][value="${cat}"]`);
  if (radio) radio.checked = true;

  applyFilters();
}

// Sort filter
function setSort(sort, el) {
  selectedSort = sort;
  document.querySelectorAll(".sort-btn").forEach(btn => btn.classList.remove("active"));
  if (el) el.classList.add("active");
  applyFilters();
}

// Reset filters
function clearFilters() {
  selectedCategory = "all";
  selectedSort = "popularity";
  document.getElementById("searchInput").value = "";
  document.getElementById("minPrice").value = "0";
  document.getElementById("maxPrice").value = "all";
  document.querySelectorAll('input[name="sideCat"]').forEach(r => r.checked = (r.value === "all"));
  document.querySelectorAll('input[name="ratingFilter"]').forEach(r => r.checked = false);
  document.querySelectorAll('input[name="discountFilter"]').forEach(r => r.checked = false);
  document.getElementById("assuredOnly").checked = false;

  document.querySelectorAll(".cat-item").forEach(t => t.classList.toggle("active", t.dataset.cat === "all"));
  document.querySelectorAll(".sort-btn").forEach(t => t.classList.toggle("active", t.dataset.sort === "popularity"));

  applyFilters();
  showToast("All filters cleared");
}

// Apply all filters and sorting
function applyFilters() {
  const query = (document.getElementById("searchInput")?.value || "").toLowerCase().trim();
  const minP = parseInt(document.getElementById("minPrice")?.value || "0", 10);
  const maxPVal = document.getElementById("maxPrice")?.value || "all";
  const maxP = maxPVal === "all" ? Infinity : parseInt(maxPVal, 10);
  const minRating = parseFloat(document.querySelector('input[name="ratingFilter"]:checked')?.value || "0");
  const minDisc = parseInt(document.querySelector('input[name="discountFilter"]:checked')?.value || "0", 10);
  const assuredOnly = document.getElementById("assuredOnly")?.checked || false;

  filtered = products.filter(p => {
    if (query) {
      const txt = (p.name + " " + p.brand + " " + p.category_name + " " + p.description).toLowerCase();
      if (!txt.includes(query)) return false;
    }
    if (selectedCategory !== "all") {
      const match = (p.category === selectedCategory || p.category_name.toLowerCase().includes(selectedCategory.replace("-", "")));
      if (!match) return false;
    }
    if (p.price < minP || p.price > maxP) return false;
    if (p.rating < minRating) return false;
    if (p.discount_percent < minDisc) return false;
    if (assuredOnly && !p.is_assured) return false;
    return true;
  });

  if (selectedSort === "price-low") filtered.sort((a, b) => a.price - b.price);
  else if (selectedSort === "price-high") filtered.sort((a, b) => b.price - a.price);
  else if (selectedSort === "rating") filtered.sort((a, b) => b.rating - a.rating);
  else if (selectedSort === "discount") filtered.sort((a, b) => b.discount_percent - a.discount_percent);
  else filtered.sort((a, b) => b.review_count - a.review_count);

  renderProducts();
}

// Render Products Grid
function renderProducts() {
  const grid = document.getElementById("productsGrid");
  const countLbl = document.getElementById("productCount");
  if (countLbl) countLbl.textContent = `(${filtered.length} equipment items)`;

  if (!grid) return;

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 50px 20px; background: #fff;">
        <div style="font-size: 40px; margin-bottom: 10px;">🚜</div>
        <h3 style="font-size: 16px; margin-bottom: 6px;">No equipment matches your search</h3>
        <p style="color: #888; font-size: 13px; margin-bottom: 14px;">Try changing filters or price limits.</p>
        <button onclick="clearFilters()" style="background:#2874f0; color:#fff; padding:8px 18px; border-radius:2px; font-weight:700;">Clear Filters</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = filtered.map(p => `
    <div class="card">
      ${p.badge ? `<span class="badge">${p.badge}</span>` : ""}
      <div class="card-img-box" onclick="viewProduct(${p.id})">
        <img src="${p.image_url}" alt="${p.name}" />
      </div>
      <div class="card-title" onclick="viewProduct(${p.id})" title="${p.name}">
        ${p.name}
      </div>
      <div class="rating-row">
        <span class="star-pill">${p.rating} ★</span>
        <span class="reviews-txt">(${Number(p.review_count).toLocaleString("en-IN")})</span>
        ${p.is_assured ? '<span class="assured-lbl">🌾 Krishi Assured</span>' : ''}
      </div>
      <div class="price-row">
        <span class="price-main">${fmtINR(p.price)}</span>
        <span class="price-old">${fmtINR(p.original_price)}</span>
        <span class="price-off">${p.discount_percent}% off</span>
      </div>
      <div class="delivery-tag">
        Free Delivery <span style="color:#388e3c; font-weight:700;">● In Stock</span>
      </div>
      <div class="card-btns">
        <button class="btn-card-add" onclick="addToCart(${p.id})">🛒 Add to Cart</button>
        <button class="btn-card-view" onclick="viewProduct(${p.id})">View Details</button>
      </div>
    </div>
  `).join("");
}

// Product Details Modal
function viewProduct(id) {
  const p = products.find(x => x.id === id);
  if (!p) return;

  const modal = document.getElementById("detailModal");
  const body = document.getElementById("detailBody");

  const specsRows = Object.entries(p.specs || {}).map(([k, v]) => `
    <tr><td class="specs-key">${k}</td><td class="specs-val">${v}</td></tr>
  `).join("");

  body.innerHTML = `
    <div class="modal-detail-grid">
      <div>
        <div class="detail-img-box">
          <img src="${p.image_url}" alt="${p.name}" />
        </div>
        <div class="detail-btns">
          <button class="btn-add-lg" onclick="addToCart(${p.id}); showToast('Added to cart!');">🛒 ADD TO CART</button>
          <button class="btn-buy-lg" onclick="buyNow(${p.id})">⚡ BUY NOW</button>
        </div>
      </div>
      <div>
        <div style="font-size:12px; color:#878787; margin-bottom:6px;">Home > ${p.category_name} > ${p.brand}</div>
        <h2 style="font-size:18px; font-weight:700; margin-bottom:8px;">${p.name}</h2>
        <div class="rating-row" style="margin-bottom:12px;">
          <span class="star-pill">${p.rating} ★</span>
          <span class="reviews-txt">${Number(p.review_count).toLocaleString("en-IN")} Farmer Ratings</span>
          ${p.is_assured ? '<span class="assured-lbl">🌾 Krishi Assured Verified</span>' : ''}
        </div>
        <div style="background:#f8fafc; border:1px solid #eee; padding:12px; border-radius:4px; margin-bottom:12px;">
          <div style="display:flex; align-items:baseline; gap:10px;">
            <span style="font-size:24px; font-weight:800;">${fmtINR(p.price)}</span>
            <span class="price-old" style="font-size:15px;">${fmtINR(p.original_price)}</span>
            <span class="price-off" style="font-size:15px;">${p.discount_percent}% off</span>
          </div>
          <div style="font-size:12px; color:#666; margin-top:4px;">Inclusive of all GST • 2-Year Warranty • 7 Days Replacement</div>
        </div>
        ${p.subsidy_info ? `
          <div style="background:#ecfdf5; border:1px solid #a7f3d0; padding:8px 12px; border-radius:3px; margin-bottom:12px; font-size:12px; color:#065f46; font-weight:600;">
            🏛️ <strong>Government Subsidy:</strong> ${p.subsidy_info}
          </div>
        ` : ''}
        <div style="font-size:13px; line-height:1.5; color:#444; margin-bottom:14px;">${p.description}</div>
        <h4 style="font-size:14px; margin-bottom:6px;">Technical Specifications</h4>
        <table class="specs-table">
          <tr><td class="specs-key">Brand</td><td class="specs-val">${p.brand}</td></tr>
          ${specsRows}
        </table>
      </div>
    </div>
  `;

  modal.classList.add("active");
}

// Cart Logic
function addToCart(id) {
  const p = products.find(x => x.id === id);
  if (!p) return;
  const existing = cart.find(i => i.id === id);
  if (existing) existing.qty += 1;
  else cart.push({ id: p.id, qty: 1, product: p });

  saveCart();
  updateCartBadge();
  showToast(p.name.slice(0, 25) + "... added!");
}

function saveCart() {
  localStorage.setItem("krishi_cart", JSON.stringify(cart));
}

function updateCartBadge() {
  const count = cart.reduce((sum, i) => sum + i.qty, 0);
  const badge = document.getElementById("cartCount");
  if (badge) badge.textContent = count;
}

function openCart() {
  const modal = document.getElementById("cartModal");
  const list = document.getElementById("cartList");
  const summary = document.getElementById("cartSummary");

  if (cart.length === 0) {
    list.innerHTML = `
      <div style="text-align:center; padding:40px 10px;">
        <div style="font-size:40px; margin-bottom:8px;">🛒</div>
        <h3>Your KrishiKart Cart is empty!</h3>
        <p style="color:#888; font-size:13px; margin-bottom:14px;">Discover best offers on farming tools.</p>
        <button onclick="closeModal('cartModal')" style="background:#2874f0; color:#fff; font-weight:700; padding:8px 20px; border-radius:2px;">Shop Now</button>
      </div>
    `;
    summary.innerHTML = "";
  } else {
    let mrp = 0;
    let total = 0;

    list.innerHTML = cart.map(item => {
      const p = item.product || products.find(x => x.id === item.id);
      if (!p) return "";
      mrp += p.original_price * item.qty;
      total += p.price * item.qty;

      return `
        <div class="cart-item">
          <img src="${p.image_url}" alt="${p.name}" />
          <div style="flex:1;">
            <div style="font-weight:600; font-size:13px;">${p.name}</div>
            <div style="font-size:11px; color:#888; margin:2px 0 6px;">Seller: Krishi Direct India</div>
            <div style="display:flex; align-items:baseline; gap:8px;">
              <span style="font-weight:800; font-size:15px;">${fmtINR(p.price * item.qty)}</span>
              <span class="price-old">${fmtINR(p.original_price * item.qty)}</span>
              <span class="price-off">${p.discount_percent}% off</span>
            </div>
            <div class="qty-pill">
              <button class="qty-btn" onclick="changeQty(${p.id}, -1)">−</button>
              <span style="font-weight:700; padding:0 6px;">${item.qty}</span>
              <button class="qty-btn" onclick="changeQty(${p.id}, 1)">+</button>
              <button class="btn-remove" onclick="removeCartItem(${p.id})">REMOVE</button>
            </div>
          </div>
        </div>
      `;
    }).join("");

    const diff = mrp - total;
    summary.innerHTML = `
      <h3 style="font-size:14px; text-transform:uppercase; color:#878787; border-bottom:1px solid #eee; padding-bottom:8px; margin-bottom:10px;">Price Details</h3>
      <div class="summary-row"><span>Price (${cart.reduce((s,i)=>s+i.qty,0)} items)</span><span>${fmtINR(mrp)}</span></div>
      <div class="summary-row"><span>Discount on MRP</span><span style="color:#388e3c; font-weight:700;">− ${fmtINR(diff)}</span></div>
      <div class="summary-row"><span>Delivery Charges</span><span style="color:#388e3c; font-weight:700;">FREE</span></div>
      <div class="summary-row summary-total"><span>Total Amount</span><span>${fmtINR(total)}</span></div>
      <div style="color:#388e3c; font-size:12px; font-weight:700; margin-bottom:14px;">✓ You save ${fmtINR(diff)} on this order</div>
      <button class="btn-checkout" onclick="openCheckout(${total})">PLACE ORDER</button>
    `;
  }

  modal.classList.add("active");
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) removeCartItem(id);
  else {
    saveCart();
    updateCartBadge();
    openCart();
  }
}

function removeCartItem(id) {
  cart = cart.filter(i => i.id !== id);
  saveCart();
  updateCartBadge();
  openCart();
  showToast("Item removed");
}

function buyNow(id) {
  const p = products.find(x => x.id === id);
  if (!p) return;
  addToCart(id);
  closeModal('detailModal');
  openCheckout(p.price);
}

function openCheckout(amt) {
  closeModal('cartModal');
  document.getElementById('checkoutTotal').textContent = fmtINR(amt);
  document.getElementById('checkoutModal').classList.add('active');
}

function placeOrder(e) {
  e.preventDefault();
  const name = document.getElementById("cName").value.trim();
  const phone = document.getElementById("cPhone").value.trim();
  const addr = document.getElementById("cAddress").value.trim();
  const pin = document.getElementById("cPin").value.trim();
  const pay = document.querySelector('input[name="cPay"]:checked')?.value || "Cash on Delivery";

  if (!name || !phone || !addr || !pin) {
    alert("Please fill all details.");
    return;
  }

  const orderId = "KK-" + Math.floor(100000 + Math.random() * 900000);
  const total = cart.reduce((s, i) => s + (i.product?.price || 0) * i.qty, 0);

  // Sync with Python backend if active
  fetch("/api/order", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ order_number: orderId, customer_name: name, phone, address: addr, pincode: pin, total_amount: total, payment_method: pay })
  }).catch(() => {});

  cart = [];
  saveCart();
  updateCartBadge();
  closeModal("checkoutModal");

  document.getElementById("orderConfirmBody").innerHTML = `
    <div style="text-align:center; padding:24px 10px;">
      <div style="font-size:44px; margin-bottom:8px;">🎉</div>
      <h2 style="font-size:20px; color:#166534; margin-bottom:6px;">Order Confirmed!</h2>
      <p style="color:#555; font-size:13px; margin-bottom:14px;">Thank you, <strong>${name}</strong>! Your farming machinery order has been placed.</p>
      <div style="background:#f8fafc; border:1px solid #ddd; padding:12px; border-radius:4px; text-align:left; font-size:13px; margin-bottom:16px;">
        <div><strong>Order ID:</strong> ${orderId}</div>
        <div><strong>Payment Mode:</strong> ${pay}</div>
        <div><strong>Estimated Delivery:</strong> 3-5 Days (Kisan Express)</div>
      </div>
      <button onclick="closeModal('orderConfirmModal')" style="background:#2874f0; color:#fff; font-weight:700; padding:10px 24px; border-radius:2px;">Continue Shopping</button>
    </div>
  `;
  document.getElementById("orderConfirmModal").classList.add("active");
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove("active");
}
