# 🌾 KrishiKart (कृषिकार्ट) - Agricultural Equipment & Farming Tools E-Commerce

A lightweight, high-performance, Flipkart-style e-commerce platform built exclusively for Indian farmers, agricultural equipment, and farming machinery.

---

## ⚡ How to Run

### Option 1: In VS Code (Click to Run)
1. Open this folder in **VS Code**.
2. Open [`app.py`](file:///d:/A_B_T/app.py) and click the **Run** (Play) button in the top right, or press **Ctrl + F5** ("Run Without Debugging").
3. Your default web browser will automatically open:
   👉 **`http://127.0.0.1:8000`**

### Option 2: One-Click Windows Launcher
- Double-click [`run.bat`](file:///d:/A_B_T/run.bat) in File Explorer.

### Option 3: Terminal Command
```bash
python app.py
```

### Option 4: Direct Offline Run (Zero Server)
- Double-click [`index.html`](file:///d:/A_B_T/index.html) to open directly in any browser. All 12 products, filters, search, and cart are pre-bundled and work 100% offline.

---

## 🚜 Key Features

- **Flipkart Aesthetic**:
  - Iconic Flipkart blue header (`#2874f0`), search bar, yellow/orange action buttons (`#ff9f00`, `#fb641b`).
  - Category navigation ribbon (Tractors & Tillers, Pumps & Irrigation, Sprayers, Harvesting, Hand Tools, Dairy).
  - Flipkart-style product cards with rating badges (`4.6 ★`), discount percentage tags, slashed MRP, and *Krishi Assured* verification labels.

- **Agricultural Equipment & Tools Catalog**:
  - **Tillage & Land Preparation**: Shaktiman 7HP Heavy Duty Rotary Tiller, AgroStar 9-Tyne Spring Cultivator.
  - **Water Pumps & Irrigation**: Kirloskar 5HP Submersible Borewell Pump, Jain Drip Irrigation 1-Acre Complete Kit.
  - **Sprayers & Pest Control**: Neptune 16L 2-in-1 Battery & Manual Knapsack Sprayer, Balwaan 40-50 Bar Triplex HTP Power Sprayer Pump.
  - **Harvesting & Cutters**: KisanKraft 35cc 4-Stroke Heavy Duty Brush Cutter & Crop Harvester, Tata Agrico Stainless Steel Serrated Sickles (Pack of 2).
  - **Farming Hand Tools**: Falcon Heavy Drop-Forged Steel Spade (Phawra / Kodali), Sharpex 10-Inch Telescopic Hedge & Pruning Shear.
  - **Dairy & Farm Machinery**: Vardhman 3HP Chaff Cutter Machine (1000 kg/hr), GrainPro Digital 14-Crop Moisture Meter.

- **Indian Rupee (₹) Pricing & Subsidy Callouts**:
  - Realistic Indian market prices in ₹ (e.g., ₹38,500 for Rotary Tiller).
  - PM Kisan / SMAM Government Subsidy eligibility indicators.
  - Kisan Credit Card (KCC) instant 10% discount tags.

- **Product Search & Multi-Filters**:
  - Live instant search across names, brands, descriptions, and categories.
  - Price Range filter (₹0 to ₹50,000+).
  - Category filter.
  - Customer Ratings filter (4.5★, 4.0★, 3.5★).
  - Discount filter (10%, 20%, 30%+).
  - Sort by Popularity, Price (Low to High), Price (High to Low), Highest Rated, and Discount.

- **Product Details View**:
  - Technical specifications table (Engine, Power, Blades, Discharge, Warranty, Origin).
  - Special offers, EMI options, and government subsidy details.
  - Verified farmer reviews from Punjab, Maharashtra, Karnataka, etc.
  - Direct "Add to Cart" and "Buy Now" buttons.

- **Shopping Cart & Checkout**:
  - Flipkart-style two-column cart drawer.
  - Real-time quantity adjustment (`+` / `−`), item removal, and MRP savings calculator.
  - Checkout form with Farmer delivery address and village/PIN fields.
  - Payment options: Cash on Delivery (COD), UPI (GPay/PhonePe), Kisan Credit Card (KCC).
  - Order success confirmation with generated Order ID (`KK-XXXXXX`) and delivery timeline estimate.

---

## 🛠️ Architecture & Clean Structure

```
d:\A_B_T\
├── app.py                     # Lightweight Python backend (http.server + sqlite3)
├── database.py                # SQLite schema creation & seed data initialization
├── krishikart.db              # SQLite Database file
├── index.html                 # Direct-run & root HTML storefront
├── run.bat                    # One-click Windows runner
├── templates\
│   └── index.html             # Server-side HTML template
├── static\
│   ├── css\
│   │   └── style.css          # Clean Flipkart-style CSS (< 25 KB)
│   ├── js\
│   │   └── app.js             # Vanilla JS (Search, Filters, Cart, Modal, Checkout)
│   └── images\                # 13 Crisp vector SVG agricultural equipment graphics
└── .vscode\
    ├── launch.json            # VS Code F5 / Run Without Debugging configuration
    └── settings.json          # Pre-configured Python interpreter path
```

---

## 🚫 Zero External Bloat
- **No npm / Node.js servers needed**
- **No pip packages required** (runs purely on Python standard library)
- **Ultra-fast load time** (< 50ms)
- **Low storage footprint** (< 1 MB total code and assets)
