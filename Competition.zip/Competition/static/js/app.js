/**
 * KrishiKart - Flipkart-style Agricultural E-Commerce
 * Lightweight Vanilla JavaScript (Zero external framework dependencies)
 */

// Application State
let allProducts = [];
let filteredProducts = [];
let currentCategory = "all";
let currentSort = "popularity";
let cart = JSON.parse(localStorage.getItem("krishikart_cart") || "[]");
let wishlist = JSON.parse(localStorage.getItem("krishikart_wishlist") || "[]");

// Format Indian Rupee currency
function formatINR(amount) {
  return "₹" + Number(amount).toLocaleString("en-IN");
}

// Toast Notification
function showToast(message) {
  let toast = document.getElementById("toastNotice");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toastNotice";
    toast.className = "toast-notice";
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span>✓</span> <span>${message}</span>`;
  toast.classList.add("show");
  setTimeout(() => {
    toast.classList.remove("show");
  }, 2800);
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  fetchProducts();
  setupEventListeners();
  updateCartBadge();
});

// Fetch Products from SQLite Backend
async function fetchProducts() {
  try {
    const res = await fetch("/api/products");
    if (res.ok) {
      allProducts = await res.json();
    } else {
      console.warn("Backend API not reachable, using fallback");
    }
  } catch (err) {
    console.warn("Fetch failed, relying on initial state or cached data:", err);
  }

  // Fallback to embedded initial products if backend API is not responding (e.g. direct file:// open)
  if (!allProducts || allProducts.length === 0) {
    if (window.INITIAL_PRODUCTS && window.INITIAL_PRODUCTS.length > 0) {
      allProducts = window.INITIAL_PRODUCTS;
    }
  }

  // If products are loaded, apply filters and render
  if (allProducts && allProducts.length > 0) {
    applyFilters();
  }
}

// Event Listeners Setup
function setupEventListeners() {
  // Search Bar
  const searchInput = document.getElementById("searchInput");
  const searchBtn = document.getElementById("searchBtn");

  if (searchInput) {
    searchInput.addEventListener("input", () => {
      applyFilters();
    });
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") applyFilters();
    });
  }

  if (searchBtn) {
    searchBtn.addEventListener("click", () => {
      applyFilters();
    });
  }

  // Price Filter Selects
  const minPriceSelect = document.getElementById("minPriceSelect");
  const maxPriceSelect = document.getElementById("maxPriceSelect");
  if (minPriceSelect) minPriceSelect.addEventListener("change", applyFilters);
  if (maxPriceSelect) maxPriceSelect.addEventListener("change", applyFilters);

  // Clear Filters
  const clearFiltersBtn = document.getElementById("clearFiltersBtn");
  if (clearFiltersBtn) {
    clearFiltersBtn.addEventListener("click", resetFilters);
  }

  // Cart Button in Header
  const headerCartBtn = document.getElementById("headerCartBtn");
  if (headerCartBtn) {
    headerCartBtn.addEventListener("click", openCartModal);
  }

  // Checkout Form Submission
  const checkoutForm = document.getElementById("checkoutForm");
  if (checkoutForm) {
    checkoutForm.addEventListener("submit", handleOrderSubmit);
  }
}

// Select Category
function selectCategory(categorySlug, el) {
  currentCategory = categorySlug;
  document.querySelectorAll(".category-tab").forEach(tab => tab.classList.remove("active"));
  if (el) el.classList.add("active");

  // Also sync sidebar checkbox if applicable
  const checkboxes = document.querySelectorAll(".category-checkbox");
  checkboxes.forEach(cb => {
    cb.checked = (cb.value === categorySlug || categorySlug === "all");
  });

  applyFilters();
}

// Select Sort Option
function setSort(sortType, el) {
  currentSort = sortType;
  document.querySelectorAll(".sort-tab").forEach(tab => tab.classList.remove("active"));
  if (el) el.classList.add("active");
  applyFilters();
}

// Reset Filters
function resetFilters() {
  currentCategory = "all";
  currentSort = "popularity";

  const searchInput = document.getElementById("searchInput");
  if (searchInput) searchInput.value = "";

  const minPriceSelect = document.getElementById("minPriceSelect");
  const maxPriceSelect = document.getElementById("maxPriceSelect");
  if (minPriceSelect) minPriceSelect.value = "0";
  if (maxPriceSelect) maxPriceSelect.value = "all";

  document.querySelectorAll('input[name="ratingFilter"]').forEach(r => r.checked = false);
  document.querySelectorAll('input[name="discountFilter"]').forEach(d => d.checked = false);
  const assuredCb = document.getElementById("assuredOnlyCheckbox");
  if (assuredCb) assuredCb.checked = false;

  document.querySelectorAll(".category-tab").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.category === "all");
  });
  document.querySelectorAll(".sort-tab").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.sort === "popularity");
  });

  applyFilters();
  showToast("Filters reset to default");
}

// Apply Filters and Sorting
function applyFilters() {
  const searchQuery = (document.getElementById("searchInput")?.value || "").toLowerCase().trim();
  const minPrice = parseInt(document.getElementById("minPriceSelect")?.value || "0", 10);
  const maxPriceVal = document.getElementById("maxPriceSelect")?.value || "all";
  const maxPrice = maxPriceVal === "all" ? Infinity : parseInt(maxPriceVal, 10);

  // Rating Filter
  const selectedRating = document.querySelector('input[name="ratingFilter"]:checked')?.value;
  const minRating = selectedRating ? parseFloat(selectedRating) : 0;

  // Discount Filter
  const selectedDiscount = document.querySelector('input[name="discountFilter"]:checked')?.value;
  const minDiscount = selectedDiscount ? parseInt(selectedDiscount, 10) : 0;

  // Assured Checkbox
  const assuredOnly = document.getElementById("assuredOnlyCheckbox")?.checked || false;

  filteredProducts = allProducts.filter(p => {
    // Search query match
    if (searchQuery) {
      const matchText = (p.name + " " + p.brand + " " + p.category_name + " " + p.description).toLowerCase();
      if (!matchText.includes(searchQuery)) return false;
    }

    // Category match
    if (currentCategory !== "all") {
      const categorySlug = p.category_name.toLowerCase().replace(/[^a-z0-9]/g, "-");
      if (!categorySlug.includes(currentCategory.replace("-", ""))) {
        // Fallback slug check
        if (p.slug && !p.slug.includes(currentCategory)) {
          // Direct check
          if (p.category_id && currentCategory === "tractors-tillers" && p.category_id !== 1) return false;
          if (p.category_id && currentCategory === "water-pumps" && p.category_id !== 2) return false;
          if (p.category_id && currentCategory === "sprayers" && p.category_id !== 3) return false;
          if (p.category_id && currentCategory === "harvesting" && p.category_id !== 4) return false;
          if (p.category_id && currentCategory === "hand-tools" && p.category_id !== 5) return false;
          if (p.category_id && currentCategory === "farm-tech" && p.category_id !== 6) return false;
        }
      }
    }

    // Price match
    if (p.price < minPrice || p.price > maxPrice) return false;

    // Rating match
    if (p.rating < minRating) return false;

    // Discount match
    if (p.discount_percent < minDiscount) return false;

    // Assured match
    if (assuredOnly && !p.is_assured) return false;

    return true;
  });

  // Sorting
  if (currentSort === "price-low") {
    filteredProducts.sort((a, b) => a.price - b.price);
  } else if (currentSort === "price-high") {
    filteredProducts.sort((a, b) => b.price - a.price);
  } else if (currentSort === "rating") {
    filteredProducts.sort((a, b) => b.rating - a.rating);
  } else if (currentSort === "discount") {
    filteredProducts.sort((a, b) => b.discount_percent - a.discount_percent);
  } else {
    // Popularity: default order or review count
    filteredProducts.sort((a, b) => b.review_count - a.review_count);
  }

  renderProducts();
}

// Render Products Grid
function renderProducts() {
  const grid = document.getElementById("productsGrid");
  const countSpan = document.getElementById("resultsCount");

  if (countSpan) {
    countSpan.textContent = `(Showing 1 – ${filteredProducts.length} of ${allProducts.length} products)`;
  }

  if (!grid) return;

  if (filteredProducts.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background: #fff;">
        <div style="font-size: 48px; margin-bottom: 12px;">🌾</div>
        <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 8px;">No agricultural equipment found</h3>
        <p style="color: #64748b; font-size: 14px; margin-bottom: 16px;">Try adjusting your search query, price range, or category filters.</p>
        <button onclick="resetFilters()" style="background: #2874f0; color: #fff; font-weight: 700; padding: 8px 20px; border-radius: 3px;">Reset All Filters</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = filteredProducts.map(p => {
    const isWished = wishlist.includes(p.id);
    return `
      <div class="product-card" data-id="${p.id}">
        ${p.badge ? `<span class="card-badge">${p.badge}</span>` : ""}
        <button class="card-wishlist-btn ${isWished ? 'active' : ''}" onclick="toggleWishlist(${p.id}, this)" title="Add to Wishlist">
          ♥
        </button>
        <div class="card-img-wrapper" onclick="openProductDetail(${p.id})">
          <img src="${p.image_url}" alt="${p.name}" class="card-img" loading="lazy" />
        </div>
        <div class="card-title" onclick="openProductDetail(${p.id})" title="${p.name}">
          ${p.name}
        </div>
        <div class="card-rating-row">
          <span class="rating-pill">${p.rating} ★</span>
          <span class="rating-count">(${Number(p.review_count).toLocaleString("en-IN")})</span>
          ${p.is_assured ? '<span class="assured-tag">🌾 Krishi Assured</span>' : ''}
        </div>
        <div class="card-price-row">
          <span class="current-price">${formatINR(p.price)}</span>
          <span class="original-price">${formatINR(p.original_price)}</span>
          <span class="discount-tag">${p.discount_percent}% off</span>
        </div>
        <div class="delivery-text">
          Free Delivery <span style="color: #388e3c; font-weight: 700;">● In Stock</span>
        </div>
        <div class="card-actions">
          <button class="btn-card-cart" onclick="addToCart(${p.id})">
            🛒 Add to Cart
          </button>
          <button class="btn-card-details" onclick="openProductDetail(${p.id})">
            View Details
          </button>
        </div>
      </div>
    `;
  }).join("");
}

// Toggle Wishlist
function toggleWishlist(productId, btn) {
  const index = wishlist.indexOf(productId);
  if (index > -1) {
    wishlist.splice(index, 1);
    btn.classList.remove("active");
    showToast("Removed from Wishlist");
  } else {
    wishlist.push(productId);
    btn.classList.add("active");
    showToast("Saved to Wishlist ♥");
  }
  localStorage.setItem("krishikart_wishlist", JSON.stringify(wishlist));
}

// Open Product Details Modal
function openProductDetail(productId) {
  const product = allProducts.find(p => p.id === productId);
  if (!product) return;

  const modal = document.getElementById("productDetailModal");
  const modalContent = document.getElementById("productDetailBody");

  let specs = {};
  try {
    specs = typeof product.specs_json === "string" ? JSON.parse(product.specs_json) : product.specs_json;
  } catch (e) {
    specs = {};
  }

  const specsRows = Object.entries(specs).map(([key, val]) => `
    <tr>
      <td class="spec-key">${key}</td>
      <td class="spec-val">${val}</td>
    </tr>
  `).join("");

  modalContent.innerHTML = `
    <div class="detail-layout">
      <!-- Left Column: Gallery & Action Buttons -->
      <div class="detail-left">
        <div class="detail-img-container">
          <img src="${product.image_url}" alt="${product.name}" class="detail-img" />
        </div>
        <div class="detail-action-buttons">
          <button class="btn-detail-cart" onclick="addToCart(${product.id}); showToast('Item added to cart!');">
            🛒 ADD TO CART
          </button>
          <button class="btn-detail-buy" onclick="buyNow(${product.id})">
            ⚡ BUY NOW
          </button>
        </div>
      </div>

      <!-- Right Column: Product Info & Specs -->
      <div class="detail-right">
        <div class="detail-breadcrumbs">
          Home > Agriculture Equipment > ${product.category_name} > ${product.brand}
        </div>
        <h1 class="detail-title">${product.name}</h1>
        
        <div class="detail-rating-row">
          <span class="rating-pill">${product.rating} ★</span>
          <span class="rating-count">${Number(product.review_count).toLocaleString("en-IN")} Ratings & Reviews</span>
          ${product.is_assured ? '<span class="assured-tag">🌾 Krishi Assured Verified</span>' : ''}
        </div>

        <div class="detail-price-box">
          <div style="display: flex; align-items: baseline; gap: 12px; margin-bottom: 6px;">
            <span class="detail-current-price">${formatINR(product.price)}</span>
            <span class="original-price" style="font-size: 16px;">${formatINR(product.original_price)}</span>
            <span class="discount-tag" style="font-size: 16px;">${product.discount_percent}% off</span>
          </div>
          <div style="font-size: 12px; color: #475569;">
            Inclusive of all taxes • Easy 7 Days Replacement Guarantee
          </div>
        </div>

        ${product.subsidy_info ? `
          <div style="background-color: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 4px; padding: 10px 14px; margin-bottom: 14px; display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 18px;">🏛️</span>
            <div>
              <div style="font-size: 12px; font-weight: 800; color: #065f46; text-transform: uppercase;">Government Subsidy Applicable</div>
              <div style="font-size: 13px; color: #047857; font-weight: 600;">${product.subsidy_info}</div>
            </div>
          </div>
        ` : ''}

        <!-- Flipkart-style Bank & Agri Offers -->
        <div class="detail-offers-box">
          <div class="offers-title">Available Special Offers</div>
          <div class="offer-item">
            <span class="offer-icon">🏷️</span>
            <span><strong>Kisan Credit Card Offer:</strong> 10% instant discount up to ₹2,500 on KCC Rupay Cards.</span>
          </div>
          <div class="offer-item">
            <span class="offer-icon">🏷️</span>
            <span><strong>FPO / Bulk Purchase:</strong> Extra 5% off on ordering 2 or more agricultural equipment.</span>
          </div>
          <div class="offer-item">
            <span class="offer-icon">🏷️</span>
            <span><strong>Free Shipping:</strong> Zero delivery fee anywhere in rural India via Kisan Express.</span>
          </div>
        </div>

        <!-- Description -->
        <div style="margin-bottom: 16px;">
          <h3 style="font-size: 14px; font-weight: 700; margin-bottom: 6px;">Product Overview</h3>
          <p style="font-size: 13px; color: #334155; line-height: 1.5;">${product.description}</p>
        </div>

        <!-- Specifications Table -->
        <div class="specs-table-section">
          <h3 class="specs-table-title">Technical Specifications</h3>
          <table class="specs-table">
            <tbody>
              <tr>
                <td class="spec-key">Brand</td>
                <td class="spec-val">${product.brand}</td>
              </tr>
              <tr>
                <td class="spec-key">Category</td>
                <td class="spec-val">${product.category_name}</td>
              </tr>
              ${specsRows}
            </tbody>
          </table>
        </div>

        <!-- Verified Farmer Reviews -->
        <div style="margin-top: 20px; border-top: 1px solid #f0f0f0; padding-top: 14px;">
          <h3 style="font-size: 15px; font-weight: 700; margin-bottom: 12px;">Verified Farmer Ratings & Reviews</h3>
          <div style="display: flex; flex-direction: column; gap: 10px;">
            <div style="background: #f8fafc; padding: 12px; border-radius: 4px;">
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span class="rating-pill">5 ★</span>
                <span style="font-weight: 700; font-size: 13px;">Exceptional build quality & performance</span>
              </div>
              <p style="font-size: 12px; color: #334155;">"Delivered right to my village farm. Very reliable machinery and fuel efficient. Saved our sugarcane intercultural labor cost immensely."</p>
              <div style="font-size: 11px; color: #64748b; margin-top: 4px;">— Ramesh Patil, Solapur, Maharashtra • <em>Verified Buyer</em></div>
            </div>
            <div style="background: #f8fafc; padding: 12px; border-radius: 4px;">
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span class="rating-pill">5 ★</span>
                <span style="font-weight: 700; font-size: 13px;">Fast delivery and genuine equipment</span>
              </div>
              <p style="font-size: 12px; color: #334155;">"Original brand piece with valid warranty card and invoice for agriculture subsidy claim. Highly recommended for all Kisan brothers."</p>
              <div style="font-size: 11px; color: #64748b; margin-top: 4px;">— Gurpreet Singh, Ludhiana, Punjab • <em>Verified Buyer</em></div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `;

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

// Close Modals
function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove("active");
    document.body.style.overflow = "auto";
  }
}

// Add Item to Cart
async function addToCart(productId) {
  const product = allProducts.find(p => p.id === productId);
  if (!product) return;

  const existing = cart.find(item => item.product_id === productId);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      product_id: productId,
      quantity: 1,
      product: product
    });
  }

  saveCart();
  updateCartBadge();
  showToast(`${product.name.slice(0, 24)}... added to cart!`);

  // Sync with Python SQLite backend
  try {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ product_id: productId, quantity: 1 })
    });
  } catch (err) {
    // Non-blocking sync
  }
}

// Save Cart to Local Storage
function saveCart() {
  localStorage.setItem("krishikart_cart", JSON.stringify(cart));
}

// Update Cart Badge Count
function updateCartBadge() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const badge = document.getElementById("cartBadge");
  if (badge) {
    badge.textContent = count;
  }
}

// Open Cart Modal / Page
function openCartModal() {
  const modal = document.getElementById("cartModal");
  const itemsContainer = document.getElementById("cartItemsList");
  const priceContainer = document.getElementById("cartPriceSummary");

  if (!modal || !itemsContainer) return;

  // Enrich cart items with product details if needed
  cart.forEach(item => {
    if (!item.product) {
      item.product = allProducts.find(p => p.id === item.product_id);
    }
  });

  if (cart.length === 0) {
    itemsContainer.innerHTML = `
      <div style="text-align: center; padding: 40px 10px;">
        <div style="font-size: 50px; margin-bottom: 12px;">🛒</div>
        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">Your KrishiKart Cart is empty!</h3>
        <p style="color: #64748b; font-size: 13px; margin-bottom: 16px;">Explore top-grade farm machinery and tools with heavy discounts.</p>
        <button onclick="closeModal('cartModal')" style="background: #2874f0; color: #fff; font-weight: 700; padding: 10px 24px; border-radius: 2px;">Shop Now</button>
      </div>
    `;
    priceContainer.innerHTML = "";
  } else {
    // Calculate totals
    let totalMRP = 0;
    let totalDiscountPrice = 0;

    itemsContainer.innerHTML = cart.map(item => {
      const p = item.product || allProducts.find(prod => prod.id === item.product_id);
      if (!p) return "";

      totalMRP += p.original_price * item.quantity;
      totalDiscountPrice += p.price * item.quantity;

      return `
        <div class="cart-item-row">
          <img src="${p.image_url}" alt="${p.name}" class="cart-item-img" />
          <div class="cart-item-info">
            <div class="cart-item-title">${p.name}</div>
            <div class="cart-item-seller">Seller: Krishi Agro Direct India • ${p.category_name}</div>
            <div style="display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px;">
              <span style="font-size: 16px; font-weight: 800;">${formatINR(p.price * item.quantity)}</span>
              <span class="original-price">${formatINR(p.original_price * item.quantity)}</span>
              <span class="discount-tag">${p.discount_percent}% Off</span>
            </div>
            <div class="qty-controls">
              <button class="qty-btn" onclick="updateItemQty(${p.id}, -1)">−</button>
              <span class="qty-val">${item.quantity}</span>
              <button class="qty-btn" onclick="updateItemQty(${p.id}, 1)">+</button>
              <button class="btn-remove-item" onclick="removeFromCart(${p.id})">REMOVE</button>
            </div>
          </div>
        </div>
      `;
    }).join("");

    const discountAmount = totalMRP - totalDiscountPrice;

    priceContainer.innerHTML = `
      <div class="price-details-title">PRICE DETAILS</div>
      <div class="price-row">
        <span>Price (${cart.reduce((s, i) => s + i.quantity, 0)} items)</span>
        <span>${formatINR(totalMRP)}</span>
      </div>
      <div class="price-row">
        <span>Discount on MRP</span>
        <span style="color: #388e3c; font-weight: 700;">− ${formatINR(discountAmount)}</span>
      </div>
      <div class="price-row">
        <span>Delivery Charges</span>
        <span style="color: #388e3c; font-weight: 700;">FREE</span>
      </div>
      <div class="price-row total">
        <span>Total Amount</span>
        <span>${formatINR(totalDiscountPrice)}</span>
      </div>
      <div class="savings-banner">
        ✓ You will save ${formatINR(discountAmount)} on this order
      </div>
      <button class="btn-place-order" onclick="openCheckoutModal(${totalDiscountPrice})">
        PLACE ORDER
      </button>
    `;
  }

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

// Update Quantity
function updateItemQty(productId, delta) {
  const item = cart.find(i => i.product_id === productId);
  if (!item) return;

  item.quantity += delta;
  if (item.quantity <= 0) {
    removeFromCart(productId);
  } else {
    saveCart();
    updateCartBadge();
    openCartModal(); // Refresh cart UI
  }
}

// Remove from Cart
function removeFromCart(productId) {
  cart = cart.filter(i => i.product_id !== productId);
  saveCart();
  updateCartBadge();
  openCartModal();
  showToast("Item removed from cart");
}

// Buy Now CTA from Details Page
function buyNow(productId) {
  const product = allProducts.find(p => p.id === productId);
  if (!product) return;

  // Add to cart if not present
  const existing = cart.find(item => item.product_id === productId);
  if (!existing) {
    cart.push({ product_id: productId, quantity: 1, product: product });
    saveCart();
    updateCartBadge();
  }

  closeModal("productDetailModal");
  openCheckoutModal(product.price);
}

// Open Checkout Modal
function openCheckoutModal(amount) {
  closeModal("cartModal");
  const modal = document.getElementById("checkoutModal");
  const totalDisplay = document.getElementById("checkoutTotalDisplay");

  if (totalDisplay) {
    totalDisplay.textContent = formatINR(amount);
  }

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

// Handle Order Placement
async function handleOrderSubmit(e) {
  e.preventDefault();

  const name = document.getElementById("custName").value.trim();
  const phone = document.getElementById("custPhone").value.trim();
  const address = document.getElementById("custAddress").value.trim();
  const pincode = document.getElementById("custPincode").value.trim();
  const state = document.getElementById("custState").value;
  const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || "Cash on Delivery";

  if (!name || !phone || !address || !pincode) {
    alert("Please fill all required delivery details.");
    return;
  }

  const orderNumber = "KK-" + Math.floor(100000 + Math.random() * 900000);
  const totalAmount = cart.reduce((sum, item) => {
    const p = item.product || allProducts.find(prod => prod.id === item.product_id);
    return sum + (p ? p.price * item.quantity : 0);
  }, 0);

  const orderPayload = {
    order_number: orderNumber,
    customer_name: name,
    phone: phone,
    address: address,
    pincode: pincode,
    state: state,
    total_amount: totalAmount,
    payment_method: paymentMethod,
    items_json: JSON.stringify(cart)
  };

  // Submit order to SQLite backend
  try {
    const res = await fetch("/api/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderPayload)
    });
    if (res.ok) {
      const data = await res.json();
      console.log("Order saved successfully:", data);
    }
  } catch (err) {
    console.warn("Could not save to backend database, completing offline:", err);
  }

  // Clear cart
  cart = [];
  saveCart();
  updateCartBadge();

  // Show Success Confirmation
  closeModal("checkoutModal");
  showOrderSuccess(orderNumber, name, totalAmount, paymentMethod);
}

// Show Order Success View
function showOrderSuccess(orderNo, name, amount, paymentMethod) {
  const modal = document.getElementById("orderSuccessModal");
  const body = document.getElementById("orderSuccessBody");

  if (!modal || !body) return;

  body.innerHTML = `
    <div class="order-success-box">
      <div class="success-icon">🎉</div>
      <h2 style="font-size: 22px; font-weight: 800; color: #166534; margin-bottom: 6px;">Order Confirmed!</h2>
      <p style="color: #475569; font-size: 14px; margin-bottom: 16px;">
        Thank you, <strong>${name}</strong>! Your agricultural equipment order has been placed successfully.
      </p>

      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin-bottom: 20px; text-align: left;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
          <span style="color: #64748b;">Order ID:</span>
          <strong>${orderNo}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
          <span style="color: #64748b;">Total Amount:</span>
          <strong style="color: #212121; font-size: 16px;">${formatINR(amount)}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
          <span style="color: #64748b;">Payment Mode:</span>
          <span style="font-weight: 600;">${paymentMethod}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #64748b;">Estimated Delivery:</span>
          <span style="color: #16a34a; font-weight: 700;">Within 3–5 Business Days (Kisan Express)</span>
        </div>
      </div>

      <div style="background: #eff6ff; border: 1px dashed #3b82f6; border-radius: 4px; padding: 10px; font-size: 12px; color: #1d4ed8; margin-bottom: 20px;">
        📄 Official GST Invoice & Agriculture Subsidy Claim Certificate will be dispatched inside the equipment box.
      </div>

      <button onclick="closeModal('orderSuccessModal')" style="background: #2874f0; color: #fff; font-weight: 700; padding: 12px 28px; border-radius: 3px; font-size: 14px;">
        Continue Shopping
      </button>
    </div>
  `;

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}
